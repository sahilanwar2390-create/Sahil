
const KEY = 'kg_state_v2', ALL = 'سب';
const PAL = ['#8A3B12', '#6B3FA0', '#1F6F50', '#B5472F', '#0F4C5C', '#3D4F8F', '#7A5C00', '#8B2F5E'];
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"]/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[m]));
const uid = () => Math.random().toString(36).slice(2, 9);
const B = (t, a, c, d, k = '') => ({ id: uid(), t, a, c, k, d, v: '', p: '' });

const def = () => ({
  title: 'کتاب گھر', tag: 'ہر کتاب کے ساتھ اس کی ویڈیو۔', color: '#0F4C5C',
  cats: ['مذہبی', 'کہانیاں', 'سوانح', 'ذاتی ترقی', 'تعلیمی', 'ناول'].map((n, i) => ({ n, c: PAL[i] })),
  classes: Array.from({ length: 12 }, (_, i) => 'جماعت ' + (i + 1)),
  books: [
    B('شریمد بھگوت گیتا', 'ویاس', 'مذہبی', 'ارجن اور شری کرشن کے درمیان زندگی، عمل اور دھرم پر مکالمہ۔'),
    B('پنچ تنتر', 'وشنو شرما', 'کہانیاں', 'جانوروں کی کہانیوں کے ذریعے اخلاق اور سمجھ کی سیکھ۔'),
    B('ونگز آف فائر', 'اے پی جے عبدالکلام', 'سوانح', 'ڈاکٹر کلام کی زندگی اور بھارت کے سائنسی سفر کی داستان۔'),
    B('اٹامک ہیبٹس', 'جیمز کلیئر', 'ذاتی ترقی', 'چھوٹی عادتوں سے بڑی تبدیلی لانے کے طریقے۔'),
    B('سائنس، جماعت دہم', 'این سی ای آر ٹی', 'تعلیمی', 'بورڈ امتحان کے لیے مکمل سائنس کا نصاب۔', 'جماعت 10'),
    B('گودان', 'پریم چند', 'ناول', 'گاؤں کے کسان ہوری کی کہانی۔'),
  ],
});

let S;
try { S = JSON.parse(localStorage.getItem(KEY)); } catch { /* fresh start */ }
S = S || def();
const save = () => localStorage.setItem(KEY, JSON.stringify(S));
let cat = ALL, kl = ALL, q = '', W, WK;
const sh = $('#sheet'), panel = $('.panel', sh);
const col = c => S.cats.find(x => x.n === c)?.c || '#4A5A5E';
const open = h => { panel.innerHTML = '<i class="grab"></i>' + h; sh.classList.add('on'); };
const close = () => sh.classList.remove('on');
const val = n => $(`[name=${n}]`, sh).value.trim();
const err = m => { $('.err', sh).textContent = m; };

function theme() {
  const h = S.color.slice(1), r = document.documentElement.style;
  const l = (parseInt(h.slice(0, 2), 16) * 299 + parseInt(h.slice(2, 4), 16) * 587 + parseInt(h.slice(4, 6), 16) * 114) / 1000;
  r.setProperty('--p', S.color); r.setProperty('--on-p', l > 150 ? '#10252A' : '#fff');
}

const card = b => `<button class="card" data-a="open" data-id="${b.id}"><div class="cover" style="--cc:${col(b.c)}"><h3>${esc(b.t)}</h3><small>${esc(b.a)}</small></div><span class="meta">${esc(b.c)}</span></button>`;
const chip = (k, v, cur, l) => `<button class="chip" aria-pressed="${v === cur}" data-${k}="${esc(v)}">${esc(l ?? v)}</button>`;

function render(keepFocus) {
  theme(); document.title = S.title;
  const list = S.books.filter(b => (cat === ALL || b.c === cat) && (kl === ALL || b.k === kl) && (!q || (b.t + ' ' + b.a).toLowerCase().includes(q)));
  const order = [...S.classes, ...new Set(list.map(b => b.k).filter(k => k && !S.classes.includes(k))), ''];
  const secs = order.map(k => { const g = list.filter(b => (b.k || '') === k); return g.length ? `<section><h2>${esc(k || 'بغیر جماعت')} <small>${g.length}</small></h2><div class="grid">${g.map(card).join('')}</div></section>` : ''; }).join('');
  $('#app').innerHTML = `<header><div><h1>${esc(S.title)}</h1><p>${esc(S.tag)}</p></div><button class="ib" data-a="head" aria-label="ترتیبات">⚙</button></header>
<main><input class="search" id="q" type="search" placeholder="کتاب یا مصنف تلاش کریں" value="${esc(q)}">
<div class="chips">${[ALL, ...S.cats.map(x => x.n)].map(c => chip('c', c, cat)).join('')}<button class="chip ghost" data-a="mcats">زمرے</button></div>
<div class="chips">${[ALL, ...S.classes].map(k => chip('k', k, kl, k === ALL ? 'سب جماعتیں' : k)).join('')}<button class="chip ghost" data-a="mcls">جماعتیں</button></div>
${secs || '<p class="empty">کوئی کتاب نہیں ملی۔</p>'}</main><button class="fab" data-a="add">+ نئی کتاب</button>`;
  if (keepFocus) { const i = $('#q'); i.focus(); i.setSelectionRange(q.length, q.length); }
}

function detail(id) {
  const b = S.books.find(x => x.id === id);
  const v = b.v || 'https://www.youtube.com/results?search_query=' + encodeURIComponent(b.t + ' ' + b.a + ' اردو');
  open(`<h2>${esc(b.t)}</h2><p class="mut">${esc(b.a)} · ${esc(b.c)}${b.k ? ' · ' + esc(b.k) : ''}</p><p>${esc(b.d)}</p>
<div class="row"><a class="btn" href="${esc(v)}" target="_blank" rel="noopener">▶ ویڈیو دیکھیں</a>${b.p ? `<a class="btn tonal" href="${esc(b.p)}" target="_blank" rel="noopener">پی ڈی ایف کھولیں</a>` : ''}</div>
<div class="row"><button class="btn ghost" data-a="edit" data-id="${id}">ترمیم</button><button class="btn ghost" data-a="del" data-id="${id}">حذف</button></div>`);
}

function form(id) {
  const b = S.books.find(x => x.id === id) || { t: '', a: '', c: S.cats[0]?.n || '', k: '', d: '', v: '', p: '' };
  const f = (l, n, t = 'text') => `<label class="fd"><span>${l}</span><input name="${n}" type="${t}" value="${esc(b[n])}"></label>`;
  const sel = (l, n, o, e) => `<label class="fd"><span>${l}</span><select name="${n}">${e ? '<option value="">—</option>' : ''}${o.map(x => `<option ${x === b[n] ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select></label>`;
  open(`<h2>${id ? 'کتاب میں ترمیم' : 'نئی کتاب'}</h2>${f('کتاب کا نام', 't')}${f('مصنف', 'a')}${sel('زمرہ', 'c', S.cats.map(x => x.n))}${sel('جماعت', 'k', S.classes, 1)}
<label class="fd"><span>تفصیل</span><textarea name="d" rows="3">${esc(b.d)}</textarea></label>${f('ویڈیو لنک', 'v', 'url')}${f('پی ڈی ایف لنک', 'p', 'url')}
<p class="err"></p><div class="row"><button class="btn" data-a="saveb" data-id="${id || ''}">محفوظ کریں</button><button class="btn ghost" data-a="x">منسوخ</button></div>`);
}

function head() {
  open(`<h2>ترتیبات</h2><label class="fd"><span>ایپ کا نام</span><input name="title" value="${esc(S.title)}"></label>
<label class="fd"><span>ذیلی سطر</span><input name="tag" value="${esc(S.tag)}"></label>
<label class="fd"><span>مرکزی رنگ</span><input name="color" type="color" value="${S.color}"></label>
<div class="row"><button class="btn" data-a="savehead">محفوظ کریں</button><button class="btn ghost" data-a="x">منسوخ</button></div>`);
}

function draw() {
  const cats = WK === 'cats';
  open(`<h2>${cats ? 'زمرے' : 'جماعتیں'}</h2>${W.map((x, i) => `<div class="mrow"><input data-i="${i}" value="${esc(x.n)}">${cats ? `<input type="color" data-ci="${i}" value="${x.c}">` : ''}<button data-a="mv" data-i="${i}" data-d="-1">↑</button><button data-a="mv" data-i="${i}" data-d="1">↓</button><button data-a="rm" data-i="${i}">✕</button></div>`).join('')}
<div class="row"><button class="btn tonal" data-a="madd">+ نیا</button></div><div class="row"><button class="btn" data-a="msave">محفوظ کریں</button><button class="btn ghost" data-a="x">منسوخ</button></div>`);
}
const sync = () => {
  sh.querySelectorAll('input[data-i]').forEach(e => { W[e.dataset.i].n = e.value.trim(); });
  sh.querySelectorAll('[data-ci]').forEach(e => { W[e.dataset.ci].c = e.value; });
};

const A = {
  open: d => detail(d.id),
  add: () => form(),
  edit: d => form(d.id),
  x: close,
  head,
  del: d => { if (confirm('کیا یہ کتاب حذف کریں؟')) { S.books = S.books.filter(b => b.id !== d.id); save(); close(); render(); } },
  saveb: d => {
    if (!val('t')) return err('کتاب کا نام لکھنا ضروری ہے۔');
    for (const n of ['v', 'p']) if (val(n) && !/^https?:\/\//i.test(val(n))) return err('لنک http:// یا https:// سے شروع ہونا چاہیے۔');
    const o = { t: val('t'), a: val('a') || 'نامعلوم مصنف', c: val('c'), k: val('k'), d: val('d'), v: val('v'), p: val('p') };
    if (d.id) Object.assign(S.books.find(x => x.id === d.id), o); else S.books.push({ id: uid(), ...o });
    save(); close(); render();
  },
  savehead: () => { S.title = val('title') || S.title; S.tag = val('tag'); S.color = val('color'); save(); close(); render(); },
  mcats: () => { WK = 'cats'; W = S.cats.map(x => ({ ...x, o: x.n })); draw(); },
  mcls: () => { WK = 'classes'; W = S.classes.map(n => ({ n, o: n })); draw(); },
  mv: d => { sync(); const i = +d.i, j = i + +d.d; if (W[j]) [W[i], W[j]] = [W[j], W[i]]; draw(); },
  rm: d => { sync(); W.splice(+d.i, 1); draw(); },
  madd: () => { sync(); W.push({ n: 'نیا', c: PAL[W.length % PAL.length] }); draw(); },
  msave: () => {
    sync(); W = W.filter(x => x.n);
    const f = WK === 'cats' ? 'c' : 'k';
    S.books.forEach(b => { b[f] = W.find(x => x.o === b[f])?.n || ''; });
    S[WK] = WK === 'cats' ? W.map(({ n, c }) => ({ n, c })) : W.map(x => x.n);
    if (cat !== ALL && !S.cats.some(x => x.n === cat)) cat = ALL;
    if (kl !== ALL && !S.classes.includes(kl)) kl = ALL;
    save(); close(); render();
  },
};

document.addEventListener('click', e => {
  if (e.target === sh) return close();
  const t = e.target.closest('[data-a],[data-c],[data-k]');
  if (!t) return;
  if (t.dataset.a) A[t.dataset.a]?.(t.dataset);
  else { if (t.dataset.c !== undefined) cat = t.dataset.c; else kl = t.dataset.k; render(); }
});
document.addEventListener('input', e => { if (e.target.id === 'q') { q = e.target.value.trim().toLowerCase(); render(true); } });
render();
